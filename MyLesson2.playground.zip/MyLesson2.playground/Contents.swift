import UIKit


/*
 Ex1:
 1.1 Declare two variables of type Float and assign each a number with a fractional part - for example, 3.14 or 42.0
 1.2 Declare another variable of type Double and assign it the sum of two variables of type Float
 1.3 Print the result with print ()

 */
var firstVariable: Float = 16.03
var secondVariable: Float = 26.02
 var sumOfFloat: Double = Double(firstVariable) + Double(secondVariable)
print("Sum of two float variable is \(sumOfFloat)")

/*
 Ex2:
 2.1 Create a variable numberOne and assign any integer value to it
 
 2.2 Create another integer variable numberTwo and assign it any value less than numberOne
 
 2.3 Set the new integer constant result to the result of dividing numberOne by numberTwo
 
 2.4 Assign the new integer constant remainder the remainder of numberOne divided by numberTwo
 
 2.5 Output to the console the message: "When dividing <...> by <...>, the result is <...>, the remainder is <...>".
 
 */
var variableNumber1 = 36
var varibaleNumber2 = 8
let result = variableNumber1 / varibaleNumber2
let remainder = variableNumber1 % varibaleNumber2

print("when dividing \(variableNumber1) by \(varibaleNumber2), the result is \(result), the remainder is \(remainder)")

/*
 Ex3:
 You need to buy several new MacBook Pro, each cost 1000 EUR.
 If you are buying 5 and more, with discount it will cost you 900 each! If you are buying 10 and more with discount it will cost you 850 each! Create if-else statements to check Conditions of buying in different amount!
 print("new: \(qty) MacBook Pro with the price of: \(price) EUR, will cost you: \(totalSum) Eur")
 */

var Mac = 5
var cost = 1000

if (Mac >= 5) { cost -= 100 }
else if (Mac >= 10) { cost -= 150}

let summary = Mac * cost

print("new: \(Mac) with the price of: \(cost) EUR, will cost you: \(summary) Eur")

/*
 Ex4:
 Create String userInputAge and put value "33a" and convert to Int to make Fatal error: Unexpectedly found nil while unwrapping an Optional value!
 Fix this Fatal error inside the if-else statements to print whenever this age can be converted to Int or not!
 */

let userInputAge = "33a"
if Int(userInputAge) != nil { print("Good to go!") }
else { print("can't converet this string to integer")}

/*
 Ex5:
 Calculate the number of years, months, days have passed from you birthday to current date.
 print("Total years: \(totalYearsFromBirth) , total months: \(totalMonthFromBirth), total days: \(totalDaysFromBirth) have passed")
 */

let calendar = Calendar.current
let currentDate = Date()

let formatter = DateFormatter()
formatter.dateFormat = "dd-MM-yyyy"


let myBirthDateString = "16-10-1995"
let myBirthDay = formatter.date(from: myBirthDateString) ?? Date()


var totalYearsFromBirth = calendar.dateComponents([.year], from: myBirthDay, to: currentDate).year
var totalMonthFromBirth = calendar.dateComponents([.month], from: myBirthDay, to: currentDate).month
var totalDaysFromBirth = calendar.dateComponents([.day], from: myBirthDay, to: currentDate).day

if totalYearsFromBirth == 0 || totalMonthFromBirth == 0 || totalDaysFromBirth == 0 {
    print("unable to check the year, months, days due to wrong myBirthDateString input" )
}else{
    print("Toatal years: \(totalYearsFromBirth ?? 0), total month: \(totalMonthFromBirth ?? 0), total days \(totalDaysFromBirth ?? 0)")
}

/*
 Ex6:
 Use Exercise 5 monthOfBirth to calculate in which quarter of the year you were born.
 Use switch case to print("I was born in the ... quarter")
 */
//=================
let myBirthDayMonth = calendar.dateComponents([.month], from: myBirthDay, to: currentDate).month!

switch myBirthDayMonth {
case 1...3:
    print("I was Born in first quarter")
case 4...6:
    print("I was Born in second quarter")
case 7...9:
    print("I was Born in third quarter")
case 10...12:
    print("I was Born in fourth quarter")
default:
    break
}

