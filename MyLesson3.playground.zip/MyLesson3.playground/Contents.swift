import UIKit

/*
 Exercise 1
 The user opens a deposit in the bank for 5 years in the amount of 500_000 Eur. The interest rate per annum \(rate). Calculate the amount of income \(profit) at the end of the \(period).
 for _ in 1...period{
 }
 print("Amount of income after \(period) years will be \(profit) Eur. My total deposit will be \(deposit) Eur !")
 */

var depositAmount: Double = 500_000
let depositPeriodInYears: Int = 5
let interestRatePerAnnum: Double = 0.75


for _ in 1...depositPeriodInYears{
    depositAmount *= interestRatePerAnnum
    }

print("Amount of income after \(depositPeriodInYears) years will be \(interestRatePerAnnum) Eur. My total deposit will be \(depositAmount) Eur !")


/*
 Exercise 2
 Create an integer array with any set of numbers and  print("My even numbers are: \(evenNumber)")
 Use a % inside the for loop.
 */

var arrayOfIntegers: [Int] = []
for i in 34...44 {
    arrayOfIntegers.append(i)
}
var evenNumberArray: [Int] = []
for number in arrayOfIntegers {
    if number % 2 == 0 {
    evenNumberArray.append(number)
}
}
print("My even numbers are: \(evenNumberArray)")

/*
 Exercise 3
 Inside the for loop create randomNumber for the random Int calculation. Calculate and print("Number 5 will be after \(counter) shuffles"). Don't forget to make a break inside the if statement.
 */
var num = 0
var shuffleCount = 0
while (num != 5) {
    num = Int.random(in: 34...44)
    shuffleCount += 1
}

    print("Number 5 will be after \(shuffleCount) shuffles")



/*
 Exercise 4
 A bug is climbing to a 10-meter electric post. During the day, bug can climb two meters, during the night she slides down to 1 meter. Determine with the help of the cycle how many days bug will climb on the top of the post. Think about which loop to use in which situation. print("bug will spend \(numberOfDays)) to reach top of the post")
 */

let heightOfElectricPost = 10
let climbingOnDayTime = 2
let climbingOnNightTime = -1

var progress = 0
var daySpent = 0
 
for _ in 1... {
    progress += climbingOnDayTime
    daySpent += 1
    
    if progress >= heightOfElectricPost {
        break
    }
    
    progress += climbingOnNightTime
}

print("bug will spend \(daySpent) to reach top of the post")

